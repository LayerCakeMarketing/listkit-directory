<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\UserList;
use App\Models\ListItem;
use App\Models\Place;
use App\Models\Tag;
use App\Models\ListCategory;
use App\Services\ProfanityFilterService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UserListController extends Controller
{
    public function index(Request $request)
    {
        $userId = auth()->id();
        
        $query = UserList::with(['owner', // Polymorphic owner
                                'user:id,name,username,custom_url,avatar', 
                                'channel:id,name,slug'])
                        ->withCount('items')
                        ->where(function($q) use ($userId) {
                            // Check polymorphic ownership
                            $q->where(function($sub) use ($userId) {
                                $sub->where('owner_type', \App\Models\User::class)
                                    ->where('owner_id', $userId);
                            })
                            // Also check legacy user_id field for backward compatibility
                            ->orWhere(function($sub) use ($userId) {
                                $sub->where('user_id', $userId)
                                    ->whereNull('owner_type');
                            });
                        });

        // Search
        if ($request->filled('search')) {
            $search = $request->search;
            $query->where(function ($q) use ($search) {
                $q->where('name', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        // Filter by visibility
        if ($request->filled('visibility')) {
            $query->where('visibility', $request->visibility);
        }

        $lists = $query->orderBy('created_at', 'desc')->paginate(12);

        return response()->json($lists);
    }

    public function store(Request $request)
    {
        \Log::info('UserListController@store - Request data:', $request->all());
        
        // If channel_id is provided, verify the user owns the channel
        if ($request->has('channel_id') && $request->channel_id) {
            \Log::info('Channel ID provided:', ['channel_id' => $request->channel_id]);
            $channel = \App\Models\Channel::findOrFail($request->channel_id);
            if ($channel->user_id !== auth()->id()) {
                return response()->json(['message' => 'You do not own this channel'], 403);
            }
        } else {
            \Log::info('No channel_id in request');
        }

        $validated = $request->validate([
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'visibility' => 'required|in:public,unlisted,private',
            'is_draft' => 'boolean',
            'scheduled_for' => 'nullable|date|after:now',
            'featured_image' => 'nullable|string', // Base64 or URL
            'featured_image_cloudflare_id' => 'nullable|string',
            'gallery_images' => 'nullable|array',
            'gallery_images.*.id' => 'nullable|string',
            'gallery_images.*.url' => 'nullable|string',
            'gallery_images.*.filename' => 'nullable|string',
            'category_id' => 'required|exists:list_categories,id',
            'channel_id' => 'nullable|exists:channels,id',
            'tags' => 'nullable|array',
            'tags.*.name' => 'string|max:255',
            'tags.*.is_new' => 'boolean',
        ]);

        DB::transaction(function() use ($validated, &$list) {
            // Determine the owner
            if (!empty($validated['channel_id'])) {
                $owner = \App\Models\Channel::findOrFail($validated['channel_id']);
            } else {
                $owner = auth()->user();
            }
            
            // Create the list with polymorphic owner
            $listData = [
                'user_id' => auth()->id(), // Keep for backward compatibility
                'channel_id' => $validated['channel_id'] ?? null, // Keep for backward compatibility
                'owner_type' => get_class($owner),
                'owner_id' => $owner->id,
                'name' => $validated['name'],
                'slug' => $this->generateUniqueSlug($validated['name'], $validated['channel_id'] ?? null),
                'description' => $validated['description'] ?? null,
                'visibility' => $validated['visibility'],
                'is_draft' => $validated['is_draft'] ?? false,
                'published_at' => (!($validated['is_draft'] ?? false) && empty($validated['scheduled_for'])) ? now() : null,
                'scheduled_for' => $validated['scheduled_for'] ?? null,
                'featured_image' => $validated['featured_image'] ?? null,
                'featured_image_cloudflare_id' => $validated['featured_image_cloudflare_id'] ?? null,
                'gallery_images' => $validated['gallery_images'] ?? null,
                'category_id' => $validated['category_id'],
            ];
            
            $list = UserList::create($listData);

            // Handle tags
            if (!empty($validated['tags'])) {
                $tagIds = [];
                
                foreach ($validated['tags'] as $tagData) {
                    if (isset($tagData['is_new']) && $tagData['is_new']) {
                        // Validate profanity for new tags
                        if (!ProfanityFilterService::validateTag($tagData['name'])) {
                            throw new \Exception('Tag "' . $tagData['name'] . '" contains inappropriate content');
                        }
                        
                        // Check if tag already exists by name/slug
                        $slug = Str::slug($tagData['name']);
                        $existingTag = Tag::where('slug', $slug)->first();
                        
                        if ($existingTag) {
                            $tagIds[] = $existingTag->id;
                        } else {
                            // Create new tag
                            $tag = Tag::create([
                                'name' => $tagData['name'],
                                'slug' => $slug,
                                'type' => 'general',
                                'color' => '#6B7280',
                                'created_by' => auth()->id(),
                            ]);
                            $tagIds[] = $tag->id;
                        }
                    } else {
                        // Use existing tag - handle both object and array formats
                        $tagId = isset($tagData['id']) ? $tagData['id'] : $tagData;
                        if (is_numeric($tagId)) {
                            $tagIds[] = $tagId;
                        }
                    }
                }
                
                $list->tags()->sync($tagIds);
            }
        });

        $list->load('owner', 'user', 'channel', 'category', 'tags');
        
        \Log::info('List created:', [
            'id' => $list->id,
            'name' => $list->name,
            'slug' => $list->slug,
            'channel_id' => $list->channel_id,
            'user_id' => $list->user_id
        ]);
        
        return response()->json([
            'message' => 'List created successfully',
            'list' => $list
        ], 201);
    }

    /**
     * Quick create a new list with default values
     * Used for frictionless list creation - immediately redirect to edit
     */
    public function quickCreate(Request $request)
    {
        // Optional: Allow channel_id to be passed for channel lists
        $channelId = $request->input('channel_id');
        
        // If channel_id is provided, verify the user owns the channel
        if ($channelId) {
            $channel = \App\Models\Channel::findOrFail($channelId);
            if ($channel->user_id !== auth()->id()) {
                return response()->json(['message' => 'You do not own this channel'], 403);
            }
            $owner = $channel;
        } else {
            $owner = auth()->user();
        }
        
        // Generate a unique untitled list name
        $baseTitle = 'Untitled List';
        $title = $baseTitle;
        $counter = 1;
        
        // Check for existing untitled lists and increment counter
        while (UserList::where('owner_type', get_class($owner))
                      ->where('owner_id', $owner->id)
                      ->where('name', $title)
                      ->exists()) {
            $counter++;
            $title = $baseTitle . ' ' . $counter;
        }
        
        // Create the list with default values
        $list = UserList::create([
            'user_id' => auth()->id(), // Keep for backward compatibility
            'channel_id' => $channelId, // Keep for backward compatibility
            'owner_type' => get_class($owner),
            'owner_id' => $owner->id,
            'name' => $title,
            'slug' => $this->generateUniqueSlug($title, $channelId),
            'description' => '',
            'visibility' => 'private', // Always default to private
            'is_draft' => true, // Start as draft
            'published_at' => null,
            'category_id' => 1, // Default category - "General" or first available
            'structure_version' => '2.0', // Use latest structure version for sections support
        ]);
        
        $list->load('owner', 'user', 'channel', 'category');
        
        return response()->json([
            'message' => 'List created successfully',
            'list' => $list
        ], 201);
    }

    public function show($id)
    {
        $list = UserList::with(['owner', 'user', 'channel', 'category', 'tags', 'items' => function($query) {
            $query->orderBy('order_index')
                  ->with(['place.location', 'place.category']);
        }])->findOrFail($id);

        // Check if user can view this list
        if (!$list->canView(auth()->user())) {
            abort(403, 'You do not have permission to view this list');
        }

        // Increment view count if not owner and list is viewable
        if (!$list->isOwnedBy(auth()->user()) && $list->isPublished()) {
            $list->incrementViewCount();
        }

        // Add saved status if user is authenticated
        if (auth()->check()) {
            $list->is_saved = $list->isSavedBy(auth()->user());
        }

        return response()->json($list);
    }

    public function update(Request $request, $id)
    {
        $list = UserList::findOrFail($id);

        if (!$list->canEdit()) {
            abort(403, 'Unauthorized to edit this list');
        }

        $validated = $request->validate([
            'name' => 'sometimes|required|string|max:255',
            'description' => 'nullable|string',
            'visibility' => 'sometimes|in:public,unlisted,private',
            'is_draft' => 'sometimes|boolean',
            'scheduled_for' => 'nullable|date|after:now',
            'featured_image' => 'nullable|string',
            'featured_image_cloudflare_id' => 'nullable|string',
            'gallery_images' => 'nullable|array',
            'gallery_images.*.id' => 'nullable|string',
            'gallery_images.*.url' => 'nullable|string',
            'gallery_images.*.filename' => 'nullable|string',
            'category_id' => 'sometimes|required|exists:list_categories,id',
            'tags' => 'nullable|array',
            'tags.*.name' => 'string|max:255',
            'tags.*.is_new' => 'boolean',
        ]);

        DB::transaction(function() use ($validated, $list) {
            if (isset($validated['name']) && $validated['name'] !== $list->name) {
                $validated['slug'] = Str::slug($validated['name']);
            }

            // Handle publishing logic
            if (isset($validated['is_draft']) && !$validated['is_draft'] && $list->is_draft) {
                // Publishing from draft
                if (empty($validated['scheduled_for'])) {
                    $validated['published_at'] = now();
                }
            }

            // Handle tags separately
            $tags = $validated['tags'] ?? null;
            unset($validated['tags']);

            $list->update($validated);

            // Update tags if provided
            if ($tags !== null) {
                $tagIds = [];
                
                foreach ($tags as $tagData) {
                    if (isset($tagData['is_new']) && $tagData['is_new']) {
                        // Validate profanity for new tags
                        if (!ProfanityFilterService::validateTag($tagData['name'])) {
                            throw new \Exception('Tag "' . $tagData['name'] . '" contains inappropriate content');
                        }
                        
                        // Check if tag already exists by name/slug
                        $slug = Str::slug($tagData['name']);
                        $existingTag = Tag::where('slug', $slug)->first();
                        
                        if ($existingTag) {
                            $tagIds[] = $existingTag->id;
                        } else {
                            // Create new tag
                            $tag = Tag::create([
                                'name' => $tagData['name'],
                                'slug' => $slug,
                                'type' => 'general',
                                'color' => '#6B7280',
                                'created_by' => auth()->id(),
                            ]);
                            $tagIds[] = $tag->id;
                        }
                    } else {
                        // Use existing tag - handle both object and array formats
                        $tagId = isset($tagData['id']) ? $tagData['id'] : $tagData;
                        if (is_numeric($tagId)) {
                            $tagIds[] = $tagId;
                        }
                    }
                }
                
                $list->tags()->sync($tagIds);
            }
        });

        $list->load('category', 'tags');

        return response()->json([
            'message' => 'List updated successfully',
            'list' => $list
        ]);
    }

    /**
     * Update a single field of the list (for inline editing)
     * Used for real-time auto-save functionality
     */
    public function patchField(Request $request, $id)
    {
        $list = UserList::findOrFail($id);

        if (!$list->canEdit()) {
            abort(403, 'Unauthorized to edit this list');
        }

        $field = $request->input('field');
        $value = $request->input('value');

        // Validate based on field
        $rules = [
            'name' => 'required|string|max:255',
            'description' => 'nullable|string',
            'visibility' => 'in:public,unlisted,private',
            'category_id' => 'exists:list_categories,id',
            'is_draft' => 'boolean',
            'featured_image_cloudflare_id' => 'nullable|string',
        ];

        if (!isset($rules[$field])) {
            return response()->json(['message' => 'Invalid field'], 400);
        }

        $validated = $request->validate([
            'value' => $rules[$field]
        ]);

        // Special handling for certain fields
        if ($field === 'name') {
            $list->name = $value;
            $list->slug = $this->generateUniqueSlug($value, $list->channel_id);
        } else {
            $list->$field = $value;
        }

        // Handle publishing logic
        if ($field === 'is_draft' && !$value && $list->is_draft) {
            $list->published_at = now();
        }

        $list->save();

        return response()->json([
            'message' => 'Field updated successfully',
            'field' => $field,
            'value' => $value,
            'slug' => $field === 'name' ? $list->slug : null
        ]);
    }

    public function destroy($id)
    {
        $list = UserList::findOrFail($id);

        if (!$list->canEdit()) {
            abort(403, 'Unauthorized to delete this list');
        }

        $list->delete();

        return response()->json(['message' => 'List deleted successfully']);
    }

    // List Items Management
    public function addItem(Request $request, $listId)
    {
        $list = UserList::findOrFail($listId);

        if (!$list->canEdit()) {
            abort(403, 'Unauthorized to edit this list');
        }

        $validated = $request->validate([
            'type' => 'required|in:directory_entry,text,location,event',
            'directory_entry_id' => 'required_if:type,directory_entry|exists:places,id',
            'title' => 'required_if:type,text,location,event|string|max:255',
            'content' => 'nullable|string',
            'data' => 'nullable|array',
            'image' => 'nullable|string',
            'affiliate_url' => 'nullable|url',
            'notes' => 'nullable|string',
        ]);

        // Get the next order index
        $maxOrder = $list->items()->max('order_index') ?? -1;
        $validated['order_index'] = $maxOrder + 1;
        $validated['list_id'] = $listId;

        // Handle location data
        if ($validated['type'] === 'location' && isset($validated['data'])) {
            // Validate location data
            $request->validate([
                'data.latitude' => 'required|numeric|between:-90,90',
                'data.longitude' => 'required|numeric|between:-180,180',
                'data.address' => 'nullable|string',
                'data.name' => 'nullable|string',
            ]);
        }

        // Handle event data
        if ($validated['type'] === 'event' && isset($validated['data'])) {
            $request->validate([
                'data.start_date' => 'required|date',
                'data.end_date' => 'nullable|date|after:data.start_date',
                'data.location' => 'nullable|string',
                'data.url' => 'nullable|url',
            ]);
        }

        $item = ListItem::create($validated);

        return response()->json([
            'message' => 'Item added successfully',
            'item' => $item->load('place')
        ], 201);
    }

    public function updateItem(Request $request, $listId, $itemId)
    {
        $list = UserList::findOrFail($listId);

        if (!$list->canEdit()) {
            abort(403, 'Unauthorized to edit this list');
        }

        $item = $list->items()->findOrFail($itemId);

        $validated = $request->validate([
            'title' => 'sometimes|required|string|max:255',
            'content' => 'nullable|string',
            'data' => 'nullable|array',
            'image' => 'nullable|string',
            'item_image' => 'nullable|string',
            'affiliate_url' => 'nullable|url',
            'notes' => 'nullable|string',
        ]);

        // Handle Cloudflare image ID
        if (isset($validated['item_image'])) {
            $validated['item_image_cloudflare_id'] = $validated['item_image'];
            unset($validated['item_image']);
        }

        $item->update($validated);

        return response()->json([
            'message' => 'Item updated successfully',
            'item' => $item
        ]);
    }

    public function removeItem($listId, $itemId)
    {
        $list = UserList::findOrFail($listId);

        if (!$list->canEdit()) {
            abort(403, 'Unauthorized to edit this list');
        }

        $item = $list->items()->findOrFail($itemId);
        $item->delete();

        // Reorder remaining items
        $list->items()
             ->where('order_index', '>', $item->order_index)
             ->decrement('order_index');

        return response()->json(['message' => 'Item removed successfully']);
    }

    public function reorderItems(Request $request, $listId)
    {
        $listModel = UserList::findOrFail($listId);

        if (!$listModel->canEdit()) {
            abort(403, 'Unauthorized to edit this list');
        }

        $validated = $request->validate([
            'items' => 'required|array',
            'items.*.id' => 'required|exists:list_items,id',
            'items.*.order_index' => 'required|integer|min:0',
        ]);

        DB::transaction(function () use ($validated, $listId) {
            foreach ($validated['items'] as $itemData) {
                ListItem::where('id', $itemData['id'])
                        ->where('list_id', $listId)
                        ->update(['order_index' => $itemData['order_index']]);
            }
        });

        return response()->json(['message' => 'Items reordered successfully']);
    }

    // Search directory entries to add to list
    public function searchEntries(Request $request)
    {
        $query = Place::with(['category', 'location'])
                              ->published();

        if ($request->filled('q')) {
            $search = $request->q;
            $query->where(function ($q) use ($search) {
                $q->where('title', 'like', "%{$search}%")
                  ->orWhere('description', 'like', "%{$search}%");
            });
        }

        $entries = $query->limit(20)->get();

        return response()->json($entries);
    }
    // Add these methods to your UserListController

/**
 * Get user's personal lists
 */
public function myLists(Request $request)
{
    $user = auth()->user();
    
    $query = UserList::with(['owner', 'items', 'category', 'tags'])
        ->where(function($q) use ($user) {
            // Check polymorphic ownership
            $q->where(function($sub) use ($user) {
                $sub->where('owner_type', \App\Models\User::class)
                    ->where('owner_id', $user->id);
            })
            // Also check legacy user_id field for backward compatibility
            ->orWhere(function($sub) use ($user) {
                $sub->where('user_id', $user->id)
                    ->whereNull('owner_type');
            });
        });
    
    // Apply filters
    if ($request->has('search') && $request->search) {
        $query->where('name', 'like', '%' . $request->search . '%');
    }
    
    if ($request->has('visibility') && $request->visibility) {
        $query->where('visibility', $request->visibility);
    }
    
    if ($request->has('is_draft')) {
        $query->where('is_draft', $request->boolean('is_draft'));
    }
    
    // Apply sorting
    $sortBy = $request->get('sort_by', 'updated_at');
    $sortOrder = $request->get('sort_order', 'desc');
    $query->orderBy($sortBy, $sortOrder);
    
    $lists = $query->paginate(12);
    
    return response()->json($lists);
}

/**
 * Get all public lists
 */
public function publicLists(Request $request)
{
    $query = \App\Models\UserList::searchable()
        ->notOnHold() // Exclude lists with on_hold status
        ->with(['user:id,name,username,custom_url,avatar', 
                'owner', // Polymorphic - load full owner
                'category:id,name,slug,color'])
        ->withCount('items');
    
    // Apply filters
    if ($request->has('search') && $request->search) {
        $query->where('name', 'like', '%' . $request->search . '%')
              ->orWhere('description', 'like', '%' . $request->search . '%');
    }
    
    if ($request->has('user') && $request->user) {
        $query->where('user_id', $request->user);
    }
    
    // Filter by category
    if ($request->has('category_id') && $request->category_id) {
        $query->where('category_id', $request->category_id);
    }
    
    // Apply sorting
    $sortBy = $request->get('sort_by', 'updated_at');
    $sortOrder = $request->get('sort_order', 'desc');
    
    switch ($sortBy) {
        case 'popularity':
            $query->orderBy('views_count', $sortOrder);
            break;
        case 'items_count':
            $query->orderBy('items_count', $sortOrder);
            break;
        case 'title':
            $query->orderBy('name', $sortOrder);
            break;
        case 'created_at':
            $query->orderBy('created_at', $sortOrder);
            break;
        default:
            $query->orderBy('updated_at', $sortOrder);
    }
    
    $perPage = $request->get('per_page', 12);
    $lists = $query->paginate($perPage);
    
    return response()->json($lists);
}

/**
 * Get list categories for filtering
 */
public function categories()
{
    // Return empty array for now since lists don't have categories
    return response()->json([]);
}

// Add these methods to your UserListController

/**
 * Get popular list creators
 */
public function popularCreators()
{
    $users = \App\Models\User::whereHas('lists', function($query) {
        $query->searchable();
    })->withCount(['lists' => function($query) {
        $query->searchable();
    }])->orderBy('lists_count', 'desc')
    ->limit(20)
    ->get(['id', 'name', 'lists_count']);
    
    return response()->json($users);
}

/**
 * Get public lists statistics
 */
public function publicListsStats()
{
    $stats = [
        'total_lists' => \App\Models\UserList::searchable()->count(),
        'total_users' => \App\Models\User::whereHas('lists', function($query) {
            $query->searchable();
        })->count(),
        'total_items' => \App\Models\ListItem::whereHas('list', function($query) {
            $query->searchable();
        })->count(),
        'total_categories' => \App\Models\ListCategory::where('is_active', true)->count()
    ];
    
    return response()->json($stats);
}

/**
 * Add list to user's favorites
 */
public function addToFavorites($listId)
{
    $user = auth()->user();
    $list = \App\Models\UserList::findOrFail($listId);
    
    // Check if already favorited
    $exists = \DB::table('user_list_favorites')
        ->where('user_id', $user->id)
        ->where('list_id', $listId)
        ->exists();
    
    if (!$exists) {
        \DB::table('user_list_favorites')->insert([
            'user_id' => $user->id,
            'list_id' => $listId,
            'created_at' => now(),
            'updated_at' => now()
        ]);
    }
    
    return response()->json(['success' => true]);
}

/**
 * Remove list from user's favorites
 */
public function removeFromFavorites($listId)
{
    $user = auth()->user();
    
    \DB::table('user_list_favorites')
        ->where('user_id', $user->id)
        ->where('list_id', $listId)
        ->delete();
    
    return response()->json(['success' => true]);
}

/**
 * Get public lists for a specific user
 */
public function userPublicLists(\App\Models\User $user)
{
    $lists = $user->lists()
        ->searchable()  // Only public lists
        ->withCount('items')
        ->latest()
        ->paginate(12);
        
    return response()->json($lists);
}

/**
 * Get all active list categories
 */
public function getAllCategories()
{
    $categories = ListCategory::where('is_active', true)
        ->orderBy('sort_order')
        ->get(['id', 'name', 'slug', 'description']);
        
    return response()->json($categories);
}

/**
 * Search tags for autocomplete
 */
public function searchTags(Request $request)
{
    $query = $request->get('q', '');
    
    if (strlen($query) < 2) {
        return response()->json([]);
    }
    
    $tags = Tag::where('is_active', true)
        ->where(function($q) use ($query) {
            $q->where('name', 'like', "%{$query}%")
              ->orWhere('slug', 'like', "%{$query}%");
        })
        ->limit(20)
        ->get(['id', 'name', 'slug', 'color']);
        
    return response()->json($tags);
}

/**
 * Validate tag name for profanity
 */
public function validateTag(Request $request)
{
    $request->validate([
        'name' => 'required|string|max:255'
    ]);
    
    $isValid = ProfanityFilterService::validateTag($request->name);
    
    return response()->json([
        'valid' => $isValid,
        'message' => $isValid ? 'Tag is valid' : 'Tag contains inappropriate content'
    ]);
}

/**
 * Get shares for a list
 */
public function getShares($listId)
{
    $list = UserList::findOrFail($listId);
    
    if (!$list->canEdit()) {
        abort(403, 'Unauthorized to view shares for this list');
    }
    
    $shares = $list->shares()->with('user')->get();
    
    return response()->json($shares);
}

/**
 * Share a list with another user
 */
public function shareList(Request $request, $listId)
{
    $list = UserList::findOrFail($listId);
    
    if (!$list->canEdit()) {
        abort(403, 'Unauthorized to share this list');
    }
    
    $validated = $request->validate([
        'user_id' => 'required|exists:users,id',
        'permission' => 'required|in:view,edit',
        'expires_at' => 'nullable|date|after:now'
    ]);
    
    // Check if already shared with this user
    $existingShare = $list->shares()->where('user_id', $validated['user_id'])->first();
    
    if ($existingShare) {
        // Update existing share
        $existingShare->update([
            'permission' => $validated['permission'],
            'expires_at' => $validated['expires_at'] ?? null,
            'shared_by' => auth()->id()
        ]);
        $share = $existingShare;
    } else {
        // Create new share
        $share = $list->shareWith(
            \App\Models\User::find($validated['user_id']), 
            $validated['permission'], 
            $validated['expires_at'] ?? null
        );
    }
    
    return response()->json([
        'message' => 'List shared successfully',
        'share' => $share->load('user')
    ]);
}

/**
 * Remove a share
 */
public function removeShare($listId, $shareId)
{
    $list = UserList::findOrFail($listId);
    
    if (!$list->canEdit()) {
        abort(403, 'Unauthorized to manage shares for this list');
    }
    
    $share = $list->shares()->findOrFail($shareId);
    $share->delete();
    
    return response()->json(['message' => 'Share removed successfully']);
}

/**
 * Search users for sharing
 */
public function searchUsers(Request $request)
{
    $query = $request->get('q', '');
    
    if (strlen($query) < 2) {
        return response()->json([]);
    }
    
    $users = \App\Models\User::where('id', '!=', auth()->id())
        ->where(function($q) use ($query) {
            $q->where('name', 'like', "%{$query}%")
              ->orWhere('username', 'like', "%{$query}%")
              ->orWhere('email', 'like', "%{$query}%");
        })
        ->limit(10)
        ->get(['id', 'name', 'username', 'email', 'avatar_url']);
        
    return response()->json($users);
}

/**
 * Get lists for a specific user by username or custom URL
 */
public function userLists($username)
{
    // Find user by custom URL or username
    $user = \App\Models\User::where('custom_url', $username)
        ->orWhere('username', $username)
        ->first();
    
    if (!$user) {
        return response()->json([
            'message' => 'User not found'
        ], 404);
    }
    
    // Get user's public lists with polymorphic ownership
    $lists = UserList::where(function($query) use ($user) {
            // Check polymorphic ownership
            $query->where(function($q) use ($user) {
                $q->where('owner_type', \App\Models\User::class)
                  ->where('owner_id', $user->id);
            })
            // Also check legacy user_id field for backward compatibility
            ->orWhere(function($q) use ($user) {
                $q->where('user_id', $user->id)
                  ->whereNull('owner_type');
            });
        })
        ->where('visibility', 'public')
        ->where('is_draft', false)
        ->with(['owner', 'category:id,name,slug', 'tags:id,name,slug,color'])
        ->withCount('items')
        ->select('id', 'user_id', 'owner_id', 'owner_type', 'name', 'slug', 'description', 'featured_image', 'featured_image_cloudflare_id', 'is_pinned', 'pinned_at', 'view_count', 'created_at', 'updated_at')
        ->orderBy('is_pinned', 'desc')
        ->orderBy('pinned_at', 'desc')
        ->orderBy('created_at', 'desc')
        ->get();
    
    return response()->json([
        'user' => [
            'id' => $user->id,
            'name' => $user->name,
            'username' => $user->username,
            'custom_url' => $user->custom_url,
            'avatar_url' => $user->avatar_url,
            'page_title' => $user->page_title,
        ],
        'lists' => $lists,
        'total' => $lists->count()
    ]);
}

/**
 * Show a specific list by user and slug
 */
public function showBySlug($username, $slug)
{
    // Find user by custom URL or username
    $user = \App\Models\User::where('custom_url', $username)
        ->orWhere('username', $username)
        ->first();
    
    if (!$user) {
        return response()->json([
            'message' => 'User not found'
        ], 404);
    }
    
    // Find the list using polymorphic ownership
    $list = UserList::where('slug', $slug)
        ->where(function($query) use ($user) {
            // Check polymorphic ownership
            $query->where(function($q) use ($user) {
                $q->where('owner_type', \App\Models\User::class)
                  ->where('owner_id', $user->id);
            })
            // Also check legacy user_id field for backward compatibility
            ->orWhere(function($q) use ($user) {
                $q->where('user_id', $user->id)
                  ->whereNull('owner_type');
            });
        })
        ->with(['owner', 'user', 'category', 'tags', 'items' => function($query) {
            $query->orderBy('order_index')
                  ->with(['place.location', 'place.category']);
        }])
        ->first();
    
    if (!$list) {
        return response()->json([
            'message' => 'List not found'
        ], 404);
    }
    
    // Check if user can view this list
    if (!$list->canView(auth()->user())) {
        return response()->json([
            'message' => 'You do not have permission to view this list'
        ], 403);
    }
    
    // Increment view count if not owner and list is viewable
    if (!$list->isOwnedBy(auth()->user()) && $list->isPublished()) {
        $list->incrementViewCount();
    }
    
    // Add saved status if user is authenticated
    if (auth()->check()) {
        $list->is_saved = $list->isSavedBy(auth()->user());
    }
    
    return response()->json($list);
}

    /**
     * Generate a unique slug for the list
     */
    private function generateUniqueSlug($name, $channelId = null)
    {
        $slug = Str::slug($name);
        $originalSlug = $slug;
        $counter = 1;

        // Check for uniqueness within the same scope (user or channel)
        while (true) {
            $query = UserList::where('slug', $slug);
            
            if ($channelId) {
                $query->where('channel_id', $channelId);
            } else {
                $query->where('user_id', auth()->id())
                      ->whereNull('channel_id');
            }
            
            if (!$query->exists()) {
                break;
            }
            
            $slug = $originalSlug . '-' . $counter;
            $counter++;
        }

        return $slug;
    }
}